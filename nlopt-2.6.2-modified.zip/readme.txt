I modify nlopt to provide ealay termination. 
It means if the solver gets a very large cost value(>1e+50), it will return with failure immediately.

This will not affect commom use.

The modified codes are in nlopt-2.6.2-modified/src/algs/luksan/plis.c, lines 261-264 and 396-400. You can just search marker "//zxzx" to get these two places.

iszhouxin@zju.edu.cn

