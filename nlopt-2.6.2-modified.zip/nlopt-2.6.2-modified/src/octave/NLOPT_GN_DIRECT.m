% NLOPT_GN_DIRECT: DIRECT (global, no-derivative)
%
% See nlopt_minimize for more information.
function val = NLOPT_GN_DIRECT
  val = 0;
